template {
    div main { 'Perl rocks' };
};
