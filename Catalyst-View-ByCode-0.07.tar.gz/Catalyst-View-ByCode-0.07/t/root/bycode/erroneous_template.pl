template {
    unknown_subname() # uups: forgot semicolon
    another_unknown()
};
